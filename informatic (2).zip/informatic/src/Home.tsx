// Home.tsx
import RotatingImage from "./RotatingImage";
import Page from "./titleOne/page";
const Home = () => {
  return (
    <div>
        <RotatingImage />
        <Page/>
    </div>
  );
};

export default Home;
