// Contact.tsx
const Informatic = () => {
  return (
    <div>
      <h1>Информатика</h1>
    </div>
  );
};

export default Informatic;
