// Contact.tsx
const Page = () => {
  return (
    <div>
      <h1>О сайте</h1>
    </div>
  );
};

export default Page;
