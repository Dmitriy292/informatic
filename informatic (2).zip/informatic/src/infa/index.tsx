// Contact.tsx
const Infa = () => {
  return (
    <div>
      <h1>Полезная информация</h1>
    </div>
  );
};

export default Infa;
